"""HaKING AI masaüstü uygulaması."""
